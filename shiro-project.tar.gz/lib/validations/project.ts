import { z } from "zod";

export const projectFormSchema = z.object({
	name: z
		.string()
		.trim()
		.min(1, "Project name is required.")
		.max(100, "Project name must be 100 characters or fewer."),

	description: z
		.string()
		.trim()
		.max(500, "Description must be 500 characters or fewer."),

	dueDate: z
		.string()
		.trim()
		.refine(
			(value) => value === "" || !Number.isNaN(Date.parse(value)),
			"Enter a valid due date.",
		),
});

export type ProjectFormData = z.infer<typeof projectFormSchema>;
