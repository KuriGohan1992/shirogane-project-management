Shiro production/demo seed kit

Add these scripts to package.json:

"db:seed:base": "tsx scripts/seed.ts",
"db:seed:shiro": "tsx scripts/seed-shiro-project.ts",
"db:seed": "pnpm db:seed:base && pnpm db:seed:shiro",
"db:production:seed": "tsx scripts/seed-production.ts",
"db:production:demo:clear": "tsx scripts/clear-production-demo-data.ts"

Keep your existing production migration script, e.g.:
"db:production:migrate": "drizzle-kit migrate --config drizzle.production.config.ts"

Add to .env.production.local (never commit this file):
PRODUCTION_DATABASE_URL=postgresql://...
PRODUCTION_SEED_USER_EMAIL=your-clerk-user-email@example.com

Recommended workflow:
pnpm db:production:migrate
pnpm db:production:seed

Show empty-state UI:
pnpm db:production:demo:clear

Restore demo data afterward:
pnpm db:production:seed

The clear command deletes every project in the production database and its cascading project data, clears notifications, and removes seed-generated users while preserving real Clerk-synchronized user rows.
